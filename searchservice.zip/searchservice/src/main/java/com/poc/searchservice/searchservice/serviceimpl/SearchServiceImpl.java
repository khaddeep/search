package com.poc.searchservice.searchservice.serviceimpl;

import com.poc.searchservice.searchservice.ResponseModel.SearchData;
import com.poc.searchservice.searchservice.service.EncodingService;
import com.poc.searchservice.searchservice.service.SearchService;
import dev.langchain4j.model.embedding.E5SmallV2EmbeddingModel;
import io.milvus.client.MilvusServiceClient;
import io.milvus.grpc.DataType;
import io.milvus.grpc.SearchResultData;
import io.milvus.param.*;
import io.milvus.param.collection.FieldType;
import io.milvus.param.dml.SearchParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class SearchServiceImpl implements SearchService {

    String uri = "https://in01-f0cdc49d8295a7f.az-eastus.vectordb.zillizcloud.com:19530";
    String user = "db_admin";
    String password = "H@thi143";
    int dim = 384;
    String collectionName = "e5_document";
    final String SEARCH_PARAM = "{\"nprobe\":10}";    // Params
    final Integer SEARCH_K = 3;                       // TopK

    final MilvusServiceClient milvusClient = new MilvusServiceClient(
            ConnectParam.newBuilder()
                    .withUri(uri)
                    .withAuthorization(user, password)
                    .build());

    List<SearchData> searchDataArrayList = new ArrayList<>();

    @Autowired
    private EncodingService encodingService;

    @Override
    public List<SearchData> search(String keywords) {
        FieldType docVector = FieldType.newBuilder()
                .withName("doc_text_vector")
                .withDataType(DataType.FloatVector)
                .withDimension(dim)
                .build();

        List<String> search_output_fields = Arrays.asList("sys_id","doc_id", "doc_text");

        System.out.println("Input::::" + keywords);

        return searchData(docVector, search_output_fields,keywords);
    }

    private List<SearchData> searchData(FieldType fieldToSearch, List<String> search_output_fields, String keywords) {
        List<Float> vectorList = encodingService.encode(new E5SmallV2EmbeddingModel(), keywords);
        List<List<Float>> search_vectors = Collections.singletonList(vectorList);
        SearchParam searchParam = SearchParam.newBuilder()
                .withCollectionName(collectionName)
                .withMetricType(MetricType.COSINE)
                .withOutFields(search_output_fields)
                .withTopK(SEARCH_K)
                .withVectors(search_vectors)
                .withVectorFieldName(fieldToSearch.getName())
                .withParams(SEARCH_PARAM)
                .build();

        SearchResultData searchResultData = milvusClient
                .search(searchParam)
                .getData()
                .getResults();

        List<Float> scoreList = searchResultData.getScoresList();

        List<Long> ids = searchResultData.getFieldsData(0)
                .getScalars()
                .getLongData()
                .getDataList();

        List<Long> docIds = searchResultData.getFieldsData(1)
                .getScalars()
                .getLongData()
                .getDataList();

        List<String> docTexts = searchResultData.getFieldsData(2)
                .getScalars()
                .getStringData()
                .getDataList();

        searchDataArrayList.clear();
        for (int i=0;i<SEARCH_K;i++) {
            SearchData searchData = new SearchData();
            searchData.setSysId(ids.get(i));
            searchData.setDoc_id(docIds.get(i));
            searchData.setScore(scoreList.get(i));
            searchData.setDoc_text(docTexts.get(i));

            searchDataArrayList.add(searchData);
        }

        return searchDataArrayList;
    }
}
