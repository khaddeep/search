package com.poc.searchservice.searchservice.service;


import com.poc.searchservice.searchservice.ResponseModel.SearchData;

import java.util.List;

public interface SearchService {

    /**
     * @param keywords
     * @return
     */
    List<SearchData> search(String keywords);

}
